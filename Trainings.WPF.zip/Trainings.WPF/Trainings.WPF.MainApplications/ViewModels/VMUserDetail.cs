﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Trainings.WPF.MainApplications.BL;
using Trainings.WPF.MainApplications.Models;

namespace Trainings.WPF.MainApplications.ViewModels
{
    public class VMUserDetail
    {


        public ObservableCollection<UserDetailModel> UserDetailCollections
        {
            get;
            set;
        }


        public UserDetailModel SelectedUser
        {
            get;
            set;
        }

        //public ICommand AddUpdateUser
        //{
        //    get;
        //    set;
        //}

        //public ICommand UserLogin
        //{
        //    get;
        //    set;
        //}

        //public ICommand ChanagePassword
        //{
        //    get;
        //    set;
        //}

        public VMUserDetail()
        {
            Init();
        }

        private void Init()
        {

            UserDetailCollections = new ObservableCollection<UserDetailModel>();
            SelectedUser = new UserDetailModel();
            //AddUpdateUser = new RCommand(AddUpdateUserDetails, Execute);
            //UserLogin = new RCommand(UserLoginCr, Execute);
            //ChanagePassword = new RCommand(UserLoginCr, Execute);
             LoadUsers();
            //LoadUsersInVM();
        }



        public void UserLoginCr(object parameter)
        {
            try
            {
                string userName = SelectedUser.UserName;
                string passwrd = SelectedUser.Password;
                //UserDetail.UserName = "SahasiDengale";
                //UserDetail.Password = "Sahasi@2812";

                //UserDetail dcUserDetail = UserConverter.Conveter(UserDetail);
                //UserDetail userDetail = new BLUserDetail().Login(dcUserDetail);
                //if (EventIsLogin != null)
                //    EventIsLogin(userDetail);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }



        public void AddUpdateUserDetails(object parameter)
        {
            BLUser blUser = new BLUser();
            blUser.AddToUser(SelectedUser);

        }



        //public UserDetail IsUserExist(string userName)
        //{
        //    UserDetail userDetail = null;
        //    if (!string.IsNullOrEmpty(userName))
        //        if (new BLUserDetail().IsRecordExist(StringEncryptDeprypt.EncryptString(userName)) == Common.EnumCRUDOperation.RecordAlreadyExist)


        //            //userDetail = UserMangementWrapper.UserServiceClient.IsUserAlreadyExist(StringEncryptDeprypt.EncryptString(userName));
        //            return userDetail;
        //}tt


        private void LoadUsers()
        {


            BLUser blUser = new BLUser();
            List<UserDetailModel> listUserDetail = blUser.GetUsers();
            // for (int iCnt = 1; iCnt <= 100; iCnt++)
            foreach (UserDetailModel usrDetail in listUserDetail)
            {
                UserDetailCollections.Add(usrDetail);
                //SelectedUser = new UserDetailModel();
                //SelectedUser.ConfirmPassword = "ConfirmPassword" + iCnt;
                //SelectedUser.CreatedBy =  iCnt;
                //SelectedUser.CreatedDate = DateTime.Now;
                //SelectedUser.Description = "Description" + iCnt;
                //SelectedUser.FinacialYearCode = iCnt;
                //SelectedUser.Description = "Description" + iCnt;
                //SelectedUser.FirstName = "FirstName" + iCnt;
                //SelectedUser.LanguageCode =   iCnt;
                //SelectedUser.LastName = "LastName" + iCnt;
                //SelectedUser.MiddleName = "MiddleName" + iCnt;
                //SelectedUser.Password = "Password" + iCnt;
                //SelectedUser.UserId = iCnt;
                //SelectedUser.UserName = "UserName" + iCnt; ;
                //UserDetailCollections.Add(SelectedUser);
            }
        }

        private void LoadUsersInVM()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["ConnString.Trainings.WPFDemo"].ConnectionString;
            SqlConnection sqlConn = new SqlConnection();
            sqlConn.ConnectionString = connectionString;

            if (sqlConn != null && sqlConn.State == System.Data.ConnectionState.Closed)
                sqlConn.Open();

            DataTable dTable = new DataTable();
            string strQuery = "select * from UserDetail";

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = sqlConn;
            cmd.CommandText = strQuery;
            SqlDataAdapter sqlda = new SqlDataAdapter();
            sqlda.SelectCommand = cmd;
            sqlda.Fill(dTable);

            foreach (DataRow dRow in dTable.Rows)
            {

                UserDetailModel userDetailModel = new UserDetailModel();
                userDetailModel.CreatedBy = Convert.ToInt16(dRow["CreatedBy"]);
                userDetailModel.CreatedDate = Convert.ToDateTime(dRow["CreatedDate"]);
                userDetailModel.Description = Convert.ToString(dRow["Description"]);
                userDetailModel.FirstName = Convert.ToString(dRow["FirstName"]);
                userDetailModel.LastName = Convert.ToString(dRow["LastName"]);
                userDetailModel.MiddleName = Convert.ToString(dRow["MiddleName"]);
                userDetailModel.ModifiedBy = Convert.ToInt16(dRow["ModifiedBy"]);
                userDetailModel.ModifiedDate = Convert.ToDateTime(dRow["ModifiedDate"]);
                userDetailModel.Password = Convert.ToString(dRow["Password"]);
                userDetailModel.UserId = Convert.ToInt16(dRow["UserCode"]);
                userDetailModel.UserName = Convert.ToString(dRow["UserName"]);
                UserDetailCollections.Add(userDetailModel);
            }


        }


        public void AddUpdateUserDetailsVM(object parameter)
        {

            string connectionString = ConfigurationManager.ConnectionStrings["ConnString.Trainings.WPFDemo"].ConnectionString;
            SqlConnection sqlConn = new SqlConnection();
            sqlConn.ConnectionString = connectionString;

            if (sqlConn != null && sqlConn.State == System.Data.ConnectionState.Closed)
                sqlConn.Open();

            string strQuery = "insert into UserDetail(UserName,[Password],FirstName,MiddleName,LastName)";
            strQuery += " values( ";
            strQuery += "'" + SelectedUser.UserName + "',";
            strQuery += "'" + SelectedUser.Password + "',";
            strQuery += "'" + SelectedUser.FirstName + "',";
            strQuery += "'" + SelectedUser.MiddleName + "',";
            strQuery += "'" + SelectedUser.LastName + "'";
            strQuery += " ) ";

            SqlCommand cmd =  new SqlCommand();
            cmd.Connection = sqlConn;
            cmd.CommandText = strQuery;
            int nRec = cmd.ExecuteNonQuery();
            
        }
    }
}

