﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Trainings.WPF.MainApplications.SQLDB;
using System.Data.SqlClient;
using Trainings.WPF.MainApplications.Models;
using System.Data;

namespace Trainings.WPF.MainApplications.DL
{
    public class DLUser
    {
        public DLUser()
        {
        }

        public bool AddToUser(UserDetailModel userDetail)
        {
            bool result = false;
            string strQuery = "insert into UserDetail(UserName,[Password],FirstName,MiddleName,LastName)";
            strQuery += " values( ";
            strQuery += "'" + userDetail.UserName + "',";
            strQuery += "'" + userDetail.Password + "',";
            strQuery += "'" + userDetail.FirstName + "',";
            strQuery += "'" + userDetail.MiddleName + "',";
            strQuery += "'" + userDetail.LastName + "'";
            strQuery += " ) ";

            DbADONetHandler adAdo = new DbADONetHandler();
            SqlCommand cmd = adAdo.GetCommand();
            cmd.CommandText = strQuery;
            int nRec = cmd.ExecuteNonQuery();

            if (nRec > 0)
                result = true;


            return result;

        }

        public DataTable GetUsers()
        {
            DataTable dTable = new DataTable();
            string strQuery = "select * from UserDetail";
            //string strQuery = "insert into UserDetail(UserName,[Password],UserName,UserName,FirstName,MiddleName,LastName)";
            //strQuery += "'" + userDetail.UserName.Trim() + "',";
            //strQuery += "'" + userDetail.Password.Trim() + "',";
            //strQuery += "'" + userDetail.FirstName.Trim() + "',";
            //strQuery += "'" + userDetail.MiddleName.Trim() + "',";
            //strQuery += "'" + userDetail.LastName + "'";

            DbADONetHandler adAdo = new DbADONetHandler();
            SqlCommand cmd = adAdo.GetCommand();
            cmd.CommandText = strQuery;
            SqlDataAdapter sqlda = adAdo.GetDataAdapter();
            sqlda.SelectCommand = cmd;
            sqlda.Fill(dTable);
            return dTable;

        }


    }


}
