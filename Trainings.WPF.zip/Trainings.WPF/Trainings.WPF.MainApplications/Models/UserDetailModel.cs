﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trainings.WPF.MainApplications.Models
{
   public  class UserDetailModel : BaseModel
    {

        private decimal userId;
        public decimal UserId
        {
            get
            {
                return userId;
            }
            set
            {
                userId = value;
                OnPropertyChanged("UserId");
            }
        }

        private string firstName;
        //  [Required(AllowEmptyStrings = false, ErrorMessage = "Username is required")]
        public string FirstName
        {
            get
            {
                return firstName;
            }
            set
            {
                firstName = value;
                OnPropertyChanged("FirstName");
            }
        }

        private string middleName;
        //  [Required(AllowEmptyStrings = false, ErrorMessage = "Username is required")]
        public string MiddleName
        {
            get
            {
                return middleName;
            }
            set
            {
                middleName = value;
                OnPropertyChanged("MiddleName");
            }
        }


        private string lastName;
        //  [Required(AllowEmptyStrings = false, ErrorMessage = "Username is required")]
        public string LastName
        {
            get
            {
                return lastName;
            }
            set
            {
                lastName = value;
                OnPropertyChanged("LastName");
            }
        }

        private string userName;
        //  [Required(AllowEmptyStrings = false, ErrorMessage = "Username is required")]
        public string UserName
        {
            get
            {
                return userName;
            }
            set
            {
                userName = value;
                OnPropertyChanged("UserName");
            }
        }


        private string password;
        public string Password
        {
            get
            {
                return password;
            }
            set
            {
                password = value;
                OnPropertyChanged("Password");
            }
        }


        private string confirmPassword;
        public string ConfirmPassword
        {
            get
            {
                return confirmPassword;
            }
            set
            {
                confirmPassword = value;
                OnPropertyChanged("ConfirmPassword");
            }
        }




        public UserDetailModel()
        {
            FinacialYearCode = 1m;
            LanguageCode = 1m;
            CreatedBy = 1m;
            CreatedDate = System.DateTime.Now;
            ModifiedBy = 1m;
            ModifiedDate = System.DateTime.Now; 
        }
    }

} 