﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Trainings.WPF.NotifyHandler;

namespace Trainings.WPF.MainApplications.Models
{
  public abstract  class BaseModel : NotifyPropertyChangeBase
    {

        #region Common Properties 

        private decimal finacialYearCode;
        public decimal FinacialYearCode
        {
            get
            {

                return finacialYearCode;
            }
            set
            {
                finacialYearCode = value;
                OnPropertyChanged("FinacialYearCode");
            }
        }

        private decimal languageCode;
        public decimal LanguageCode
        {
            get
            {
                return languageCode;
            }
            set
            {
                languageCode = value;
                OnPropertyChanged("LanguageCode");
            }
        }

        private string description;
        public string Description
        {
            get
            {

                return description;
            }
            set
            {
                description = value;
                OnPropertyChanged("Description");
            }
        }

        private decimal createdBy;
        public decimal CreatedBy
        {
            get
            {
                return createdBy;
            }
            set
            {
                createdBy = value;
                OnPropertyChanged("CreatedBy");
            }
        }

        private DateTime createdDate;
        public DateTime CreatedDate
        {
            get
            {
                if (createdDate == DateTime.MaxValue || createdDate == DateTime.MinValue)
                    createdDate = DateTime.Now;
                return createdDate;
            }
            set
            {
                createdDate = value;
                OnPropertyChanged("CreatedDate");
            }
        }

        private decimal modifiedBy;
        public decimal ModifiedBy
        {
            get
            {
                return modifiedBy;
            }
            set
            {
                modifiedBy = value;
                OnPropertyChanged("ModifiedBy");
            }
        }

        private DateTime modifiedDate;
        public DateTime ModifiedDate
        {
            get
            {
                if (modifiedDate == DateTime.MaxValue || modifiedDate == DateTime.MinValue)
                    modifiedDate = DateTime.Now;
                return modifiedDate;
            }
            set
            {
                modifiedDate = value;
                OnPropertyChanged("ModifiedDate");
            }
        }
        #endregion Common Properties


       

        public BaseModel()
        {
        }
    }
}
