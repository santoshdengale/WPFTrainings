﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Trainings.WPF.MainApplications.DL;
using Trainings.WPF.MainApplications.Models;

namespace Trainings.WPF.MainApplications.BL
{
    public class BLUser
    {
        public bool AddToUser(UserDetailModel userDetail)
        {
            DLUser dlUser = new DLUser();
            bool result = dlUser.AddToUser(userDetail);
            return result;

        }

        public List<UserDetailModel> GetUsers()
        {
            List<UserDetailModel> listUserDetail = new List<UserDetailModel>();
            DLUser dlUser = new DLUser();
            DataTable dTable = dlUser.GetUsers();

            foreach (DataRow dRow in dTable.Rows)
            {

                UserDetailModel userDetailModel = new UserDetailModel();
                userDetailModel.CreatedBy = Convert.ToInt16( dRow["CreatedBy"]);
                userDetailModel.CreatedDate = Convert.ToDateTime(dRow["CreatedDate"]);
                userDetailModel.Description = Convert.ToString(dRow["Description"]);
                userDetailModel.FirstName = Convert.ToString(dRow["FirstName"]);
                userDetailModel.LastName = Convert.ToString(dRow["LastName"]);
                userDetailModel.MiddleName = Convert.ToString(dRow["MiddleName"]);
                userDetailModel.ModifiedBy = Convert.ToInt16(dRow["ModifiedBy"]);
                userDetailModel.ModifiedDate = Convert.ToDateTime(dRow["ModifiedDate"]);
                userDetailModel.Password = Convert.ToString(dRow["Password"]);
                userDetailModel.UserId = Convert.ToInt16(dRow["UserCode"]);
                userDetailModel.UserName = Convert.ToString(dRow["UserName"]);
                listUserDetail.Add(userDetailModel);
            }

            return listUserDetail;
        }
    }
}
