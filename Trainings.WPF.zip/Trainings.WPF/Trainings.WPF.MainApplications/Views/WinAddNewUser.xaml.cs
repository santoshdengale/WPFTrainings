﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Trainings.WPF.MainApplications.Views
{
    /// <summary>
    /// Interaction logic for WinAddNewUser.xaml
    /// </summary>
    public partial class WinAddNewUser : Window
    {
        public WinAddNewUser()
        {
            InitializeComponent();
        }

        private void txtBoxUserName_LostFocus(object sender, RoutedEventArgs e)
        {

        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void btnAddUpdateUser_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                nmVMUserDetail.SelectedUser.Password = pwdBox.Password.Trim();
                nmVMUserDetail.SelectedUser.ConfirmPassword = pwdBoxConfirm.Password.Trim();
                nmVMUserDetail.AddUpdateUserDetailsVM(null);

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
