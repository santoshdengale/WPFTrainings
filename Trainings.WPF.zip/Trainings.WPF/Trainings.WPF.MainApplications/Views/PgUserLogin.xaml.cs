﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Trainings.WPF.MainApplications.Views
{
    /// <summary>
    /// Interaction logic for PgUserLogin.xaml
    /// </summary>
    public partial class PgUserLogin : Page
    {
        public PgUserLogin()
        {

            try
            {
                InitializeComponent();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void Page_Unloaded(object sender, RoutedEventArgs e)
        {

        }

        private void cmbBoxFinancialYear_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            
        }

        private void hyerLnkForgotPassword_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                 
                nmVMUserDetail.SelectedUser.Password = passwordBox.Password;
                nmVMUserDetail.UserLoginCr(null);
                //              nmVMUserDetail.UserDetail.
                //this.nmVMUserDetail.UserDetail.
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.ToString());
            }
        }

        private void hyperLinkRegisterUser_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
