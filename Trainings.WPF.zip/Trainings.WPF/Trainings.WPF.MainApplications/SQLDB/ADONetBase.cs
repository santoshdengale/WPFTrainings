﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trainings.WPF.MainApplications.SQLDB
{
    public abstract class ADONetBase
    {

        private readonly string connectionString = string.Empty;
        protected SqlConnection sqlConn;
        public ADONetBase()
        {
            connectionString = @"Data Source=ADMIN-PC;Initial Catalog=DbTraining;Integrated Security=True";
            Init();
        }

        private void Init()
        {
            sqlConn = new SqlConnection();
            sqlConn.ConnectionString = connectionString;

            if (sqlConn != null && sqlConn.State == System.Data.ConnectionState.Closed)
                sqlConn.Open();


        }



    }
}

