﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Trainings.WPF.MainApplications.SQLDB
{
  public   class DbADONetHandler : ADONetBase
    {
        public DbADONetHandler()
        { }

        public SqlCommand GetCommand()
        {
            SqlCommand sqlCmd = new SqlCommand();
            sqlCmd.Connection = base.sqlConn;
            return sqlCmd;
        }


        public SqlDataAdapter GetDataAdapter()
        {
            SqlDataAdapter sqlDa = new SqlDataAdapter();
            return sqlDa;
        }


        public SqlParameter GetParameter()
        {
            SqlParameter para = new SqlParameter();
            return para;
        }


        public SqlDataReader GetDataReader()
        {
            SqlDataReader dataReader = null; // new  SqlDataReader();
            return dataReader;
        }

        public SqlConnection GetConnection()
        {
            return base.sqlConn;
        }
    }
}
