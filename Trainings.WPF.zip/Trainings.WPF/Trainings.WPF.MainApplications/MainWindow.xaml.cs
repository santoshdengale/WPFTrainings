﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Trainings.WPF.MainApplications.Views;

namespace Trainings.WPF.MainApplications
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
          
            try
            {
                InitializeComponent();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void hyperLinkRegisterUser_Click(object sender, RoutedEventArgs e)
        {

        }

        private void hyprLinkLogIn_Click(object sender, RoutedEventArgs e)
        {

        }

        private void hyprLinkLogOut_Click(object sender, RoutedEventArgs e)
        {

        }

        private void hyprLinkCreateUser_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                this.MainFrame.Content = new PgUserLogin();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void hyprLinkCustomer_Click(object sender, RoutedEventArgs e)
        {

        }

        private void hyprLinkCompany_Click(object sender, RoutedEventArgs e)
        {

        }

        private void hyprLinkItem_Click(object sender, RoutedEventArgs e)
        {

        }

        private void hyprLinkUnit_Click(object sender, RoutedEventArgs e)
        {

        }

        private void hyprLinkPacking_Click(object sender, RoutedEventArgs e)
        {

        }

        private void hyprLinkCity_Click(object sender, RoutedEventArgs e)
        {

        }

        private void hyprLinkTransportMode_Click(object sender, RoutedEventArgs e)
        {

        }

        private void hyprLinkHSN_Click(object sender, RoutedEventArgs e)
        {

        }

        private void hyprLinkPurchaseOrders_Click(object sender, RoutedEventArgs e)
        {

        }

        private void hyprLinkTaxInvoic_Click(object sender, RoutedEventArgs e)
        {

        }

        private void hyprLinkInvoiceReport_Click(object sender, RoutedEventArgs e)
        {

        }

        private void hyprLinkShowReport_Click(object sender, RoutedEventArgs e)
        {

        }

        private void hyprLinkTransporter_Click(object sender, RoutedEventArgs e)
        {

        }

        private void hyprLinkUserList_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                this.MainFrame.Content = new PgUserList();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
    }
}
