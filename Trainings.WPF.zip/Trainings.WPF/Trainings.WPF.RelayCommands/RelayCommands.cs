﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace Trainings.WPF.RelayCommands
{
    //https://www.codeproject.com/Tips/813345/Basic-MVVM-and-ICommand-Usage-Example
    public class RelayCommands : RelayCommandsBase
    {
        

        public RelayCommands(Action<object> execute, Func<object, bool> canExecute = null) 
        {
            if (execute == null)
            {
                throw new ArgumentNullException("execute");
            }

            if (canExecute == null)
            {
                throw new ArgumentNullException("canExecute");
            }

            base.ActionExecute = execute;
            this.FunCanExecute = canExecute;
        }

        public virtual bool CanExecute(object parameter)
        {
            // return this.ActionExecute == null || this.ActionExecute(parameter);
            return true;
        }

        
    }
}

